# Una función que solo se encarga de ejecutar
# La función puede recibir cualquier cantidad 
# De argumentos y argumentos claves siempre
def excecute(*args, **kwargs):
    print("¡Hola Mundo!")
    return 1


# Funciones definidas poor el usuario
def pluginfn_hello_lucas(*args, **kwargs):
    print("¡Hello lucas!")

# otra funcion
def pluginfn_adios_lucas(*args, **kwargs):
    print("¡Hasta Luego Lucas!")

# Información del plugin 
def info(*args, **kwargs):
    print("Hello World Plugin")
    print(f"Creado por {kwargs['author']}")
    print("Descripción:")
    print(f"{kwargs['description']}")
    print("Gracias por usar el plugin.")