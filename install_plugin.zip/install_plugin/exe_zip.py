def excecute(*args, **kwargs):
    print("Instalado desde un Github")