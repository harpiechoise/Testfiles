# Python trivia game
import pip 
import random
from xml.sax.saxutils import unescape

try:
    # Intentamos importar requests
    import requests
except ModuleNotFoundError:
    # Si no podemos importar requests, instalamos requests
    pip.main(['install', 'requests'])
finally:
    # Importamos requests
    import requests
    
try:
    # intentamos importar una libreria
    from w3lib.html import replace_entities
except ModuleNotFoundError:
    # Si no podemos importar la libreria, instalamos la libreria
    pip.main(['install', 'w3lib'])
finally:
    # Importamos la libreria
    from w3lib.html import replace_entities

# Hacemos una consulta a la API de trivia
def make_trivia_request(n_questions=1, dificulty='easy'):
    # Hacemos una peticion a la API de trivia
    data = requests.get(f"https://opentdb.com/api.php?amount=\
        {n_questions}&difficulty={dificulty}").json()
    return data

# Mostramos las preguntas y las respuestas
# Que nos devuelve la API.
def show_question(question):
    # Mostramos la pregunta
    print(replace_entities(question['question']))
    # Aleatorizamos las respuestas
    all_answers = question['incorrect_answers'].copy()
    all_answers.append(question['correct_answer'])
    random.shuffle(all_answers)
    
    # Mostramos las respuestas
    # Ademas, le asignamos una letra a cada respuesta
    possible_inputs = 'ABCDEFGHI'[:len(all_answers)]
    for answer, character in zip(all_answers, possible_inputs):
        print(f"{character}) {replace_entities(answer)}")
    
    # Pedimos entrada al usuario
    user_answer = input("Your answer: ")
    if user_answer.upper() in possible_inputs:
        # Rescatamos el indice de la respuesta dada por el usuario
        alternative = possible_inputs.index(user_answer.upper())
        # Rescatamos la respuesta dada por el usuario
        answer = all_answers[alternative]
        # Si la respuesta es correcta, sumamos un punto
        if answer == question['correct_answer']:
            print("¡Respuesta correcta!")
            return 1
        # Si la respuesta es incorrecta, no sumamos nada
        if answer != question['correct_answer']:
            print("¡Respuesta incorrecta!")
            print(f"La respuesta correcta era: {replace_entities(question['correct_answer'])}")
            return 0

# Esta es la funcion principal del plugin
def excecute(*args, **kwargs):
    # Preguntamos por el numero de preguntas en la ronda
    # y la dificultad de las preguntas
    if "n_questions" in kwargs:
        n_questions = kwargs['n_questions']
    else:
        try:
          n_questions = int(input("Escoje el numero de preguntas de la ronda: "))
        except:
          # Si no es un numero, le preguntamos al usuario
          # Otra vez
          excecute()
    
    # Se pregunta en ingles la dificultad para poder usar la API mas facilmente
    dificulty = input("¿Que tan dificiles quieres las preguntas? (easy, medium, hard): ")
    
    # Si la dificultad no es valida, se le pide que la ingrese de nuevo
    if dificulty.lower() not in ['easy', 'medium', 'hard']:
        print("Dificultad no valida")
        return excecute(n_questions=n_questions)
    
    # Inicializamos el contador de puntos
    score = 0
    questions = make_trivia_request(n_questions=n_questions, dificulty=dificulty.lower())
    # Recorremos las preguntas
    # Y las mostramos
    for i in questions['results']:
        score += show_question(i)
        # Mostramos el puntaje
        print("Your Score:", score)
